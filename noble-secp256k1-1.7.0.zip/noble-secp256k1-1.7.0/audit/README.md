# Audit

The PDF was saved from cure53.de site: [URL](https://cure53.de/pentest-report_noble-lib.pdf). See information about audit and fuzzing in root [README](../README.md).

## rpc_psbt.json

From https://github.com/bitcoin/bitcoin/pull/21283/files#diff-28226b793a8b81677483f02a1884de0e1f7cea46861ba35bae0434ac289dab48

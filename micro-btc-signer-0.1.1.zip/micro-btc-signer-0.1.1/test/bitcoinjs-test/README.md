# Tests

NPM & ESM is burning trashpile.
Run via `node --experimental-loader ./esm_loader.js index.test.js`.

Uses MIT licensed vectors from:

- https://github.com/bitcoinjs/bitcoinjs-lib
- https://github.com/bitcoincoretech/bitcoinjs-lib/tree/p2tr-v1
- https://github.com/BitGo/bitcoinjs-lib

import { should } from 'micro-should';

import './btcjs.test.js';
import './btcjs-taproot.test.js';
import './btcjs-address.test.js';

should.run();
